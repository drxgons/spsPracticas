"""
API REST sencilla con Python y FLask
Por: Omar Alejandro Lemuz Fuentes
"""

from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/api/sps/helloworld/v1', methods=['GET'])
def response():
    response = {'message': 'salida', 'state': 'success'}
    return jsonify(response)

if __name__ == "__main__":
    app.run(host = '0.0.0.0', port = 8090)


